# Timeseries_predictive_modelling
Exercises for learning predictive modelling of time series data
